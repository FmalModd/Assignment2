#include "Parser.h"
#include <iostream>
#include <stdlib.h>

Parser::Parser() { }

Parser::Parser(Lexer lexer) : lexer(lexer) { }

Token nextToken;
bool assign = false;

void Parser::parse() {
	nextToken = lexer.nextToken();
	statements();
}

void Parser::statements() {
	if(nextToken.getToken() == END) {
		exit(0);
	} else {
		statement();
		if(nextToken.getToken() == SEMICOL) {
			if(assign) {
				cout << "ASSIGN" << endl;
				assign = false;
			}
			nextToken = lexer.nextToken();
			statements();
		} else {
			cout << "this is the only statements error!" << endl;
			error();
		}
	}
}

void Parser::statement() {
	if(nextToken.getToken() == ID) {
		cout << "PUSH " << nextToken.getLexeme() << endl;
		nextToken = lexer.nextToken();
		if(nextToken.getToken() == ASSIGN) {
			nextToken = lexer.nextToken();
			expr();
			assign = true;
			//cout << "ASSIGN" << endl;
		} else {
			cout << "this is statement error 1 !" << endl;
			error();
		}
	} else if(nextToken.getToken() == PRINT) {
		nextToken = lexer.nextToken();
		if(nextToken.getToken() == ID) {
			cout << "PUSH " << nextToken.getLexeme() << endl;
			nextToken = lexer.nextToken();
		} else {
			//cout << "this is statement error 2 !" << endl;
			error();
		}
		cout << "PRINT" << endl;
	} else {
		cout << "this is statement error 3 !" << endl;
		cout << nextToken.getLexeme() << endl;
		cout << nextToken.getToken() << endl;
		error();
	}
}

void Parser::expr() {
	term();
	if(nextToken.getToken() == PLUS) {
		nextToken = lexer.nextToken();
		expr();
		cout << "ADD" << endl;
	} else if(nextToken.getToken() == MINUS) {
		nextToken = lexer.nextToken();
		expr();
		cout << "SUB" << endl;
	} 
}

void Parser::term() {
	factor();
	if(nextToken.getToken() == MULT) {
		nextToken = lexer.nextToken();
		term();
		cout << "MULT" << endl;
	}
}

void Parser::factor() {
	if(nextToken.getToken() == INT) {
		cout << "PUSH " << nextToken.getLexeme() << endl;
		nextToken = lexer.nextToken();
	} else if(nextToken.getToken() == ID) {
		cout << "PUSH " << nextToken.getLexeme() << endl;
		nextToken = lexer.nextToken();
	} else if(nextToken.getToken() == LPAREN) {
		nextToken = lexer.nextToken();
		expr();
		if(nextToken.getToken() == RPAREN) {
			nextToken = lexer.nextToken();
		} else {
			cout << "this is factor error 1 !" << endl;
			error();
		}
	} else {
		cout << "this is factor error 2 !" << endl;
		error();
	}
}

void Parser::error() {
	cout << "Syntax error!" << endl;
	exit(0);
}


